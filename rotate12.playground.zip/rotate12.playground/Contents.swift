func rotate1(_ nums: inout [Int], _ k: Int) {
    var d = k
    if nums.count == 0 || nums.count == 1 {
        return
    }
    if d < 0 {
        print("К выбран неверно!")
    }else{
        while d > nums.count {
            d = d - nums.count
        }
        let we = nums.suffix(d)
        nums.reverse()
        var qw = nums.suffix(nums.count - d)
        qw.reverse()
        nums = Array(we + qw)
    }
}
var array1 = [1,2,3,45,6,7,89,12]
rotate1(&array1, 4)
print(array1)



func rotate2(_ nums: inout [Int], _ k: Int) {
    var d = k
    if nums.count == 0 || nums.count == 1 {
        return
    }
    if d < 0 {
        print("К выбран неверно!")
    } else {
        while d >= nums.count {
            d = d - nums.count
            
        }
        var i = 0
        while i<d {
            let m = nums.last!
            nums.insert(m, at: 0)
            nums.removeLast()
            i = i + 1
        }
    }
}
var array2 = [2,34,55,4]
rotate2(&array2, 2)
print(array2)


func rotate3(_ nums: inout [Int], _ k: Int) {
    var d = k
    if nums.count == 0 || nums.count == 1 {
        return
    }
    while d > nums.count {
        d = d - nums.count
    }
    let ki = nums.dropFirst(nums.count-d)
    let ku = nums.dropLast(d)
    nums = Array(ki+ku)
    
}

var array3 = [1,2,5,2,3,5235,-66,3243,2,35,-1235,12,51]
rotate3(&array3, 4)
print(array3)

func rotate4(_ nums: inout [Int], _ k: Int) {
    var a = k
    if nums.count == 0 || nums.count == 1 {
        return
    }
    if a < 0 {
        print("К выбран неверно!")
        
    } else {
        
        while a > nums.count {
            a = a - nums.count
        }
        for _ in 1...nums.count-a {
            let y = nums.remove(at: 0)
            nums.append(y)
        }
    }
}

var array4 = [1,2,3,4,5,6,2,2,34,23,421,34,1,9]
rotate4(&array4, 2)
print(array4)



